rootGroup = 'image_loader'
