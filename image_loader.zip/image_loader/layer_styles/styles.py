# -*- coding: utf-8 -*-
"""
Created on Fri Jun 17 14:23:40 2022

@author: Drew.Bennett
"""

import os

crackStyle = os.path.join(os.path.dirname(__file__),'cracking.qml')
