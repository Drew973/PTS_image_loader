


pyuic5 image_loader_dockwidget_base.ui -o image_loader_dockwidget_base.py

